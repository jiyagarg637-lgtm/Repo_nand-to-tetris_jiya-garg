// Adds 2 and 3
@2
D=A
@3
D=D+A
@0
M=D
